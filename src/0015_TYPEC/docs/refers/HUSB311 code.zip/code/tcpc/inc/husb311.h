/*
 * Copyright (C) 2020 Hynetek Inc.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 */

#ifndef __LINUX_HUSB311_H
#define __LINUX_HUSB311_H

#include "std_tcpci_v10.h"
#include "pd_dbg_info.h"

/*show debug message or not */
#define ENABLE_HUSB311_DBG	0

/* HUSB311 Private RegMap */

#define HUSB311_REG_BMC_CTRL				(0x90)
//#define HUSB311_REG_VBUS_SENSE              (0x91)
#define HUSB311_REG_BMCIO_RXDZSEL			(0x93)
#define HUSB311_REG_VCONN_CLIMITEN			(0x95)

#define HUSB311_REG_HT_STATUS				(0x97)
#define HUSB311_REG_HT_INT					(0x98)
#define HUSB311_REG_HT_MASK					(0x99)

#define HUSB311_REG_IDLE_CTRL				(0x9B)
#define HUSB311_REG_INTRST_CTRL				(0x9C)
#define HUSB311_REG_WATCHDOG_CTRL			(0x9D)
#define HUSB311_REG_I2CRST_CTRL				(0X9E)
//#define HUSB311_REG_FORCE_CC				(0x9F)

#define HUSB311_REG_SWRESET				(0xA0)
#define HUSB311_REG_TTCPC_FILTER			(0xA1)
#define HUSB311_REG_DRP_TOGGLE_CYCLE		(0xA2)
#define HUSB311_REG_DRP_DUTY_CTRL			(0xA3)
//#define HUSB311_REG_HT_CFG1				(0xA5)
//#define HUSB311_REG_HT_CFG2				(0xA5)

#define HUSB311_REG_BMCIO_RXDZEN			(0xAF)

#define HUSB311_REG_UNLOCK_PW_2				(0xF0)
#define HUSB311_REG_UNLOCK_PW_1				(0xF1)
#define HUSB311_REG_EFUSE5				(0xF6)

/*
 * Device ID
 */

#define HUSB311_DID             0x0
/*
 * HUSB311_REG_PHY_CTRL1			(0x80)
 */

#define HUSB311_REG_PHY_CTRL1_SET( \
	retry_discard, toggle_cnt, bus_idle_cnt, rx_filter) \
	((retry_discard << 7) | (toggle_cnt << 4) | \
	(bus_idle_cnt << 2) | (rx_filter & 0x03))

/*
 * HUSB311_REG_CLK_CTRL2			(0x87)
 */

#define HUSB311_REG_CLK_DIV_600K_EN		(1<<7)
#define HUSB311_REG_CLK_BCLK2_EN		(1<<6)
#define HUSB311_REG_CLK_BCLK2_TG_EN		(1<<5)
#define HUSB311_REG_CLK_DIV_300K_EN		(1<<3)
#define HUSB311_REG_CLK_CK_300K_EN		(1<<2)
#define HUSB311_REG_CLK_BCLK_EN			(1<<1)
#define HUSB311_REG_CLK_BCLK_TH_EN		(1<<0)

/*
 * HUSB311_REG_CLK_CTRL3			(0x88)
 */

#define HUSB311_REG_CLK_OSCMUX_RG_EN	(1<<7)
#define HUSB311_REG_CLK_CK_24M_EN		(1<<6)
#define HUSB311_REG_CLK_OSC_RG_EN		(1<<5)
#define HUSB311_REG_CLK_DIV_2P4M_EN		(1<<4)
#define HUSB311_REG_CLK_CK_2P4M_EN		(1<<3)
#define HUSB311_REG_CLK_PCLK_EN			(1<<2)
#define HUSB311_REG_CLK_PCLK_RG_EN		(1<<1)
#define HUSB311_REG_CLK_PCLK_TG_EN		(1<<0)

/*
 * HUSB311_REG_BMC_CTRL				(0x90)
 */

#define HUSB311_REG_IDLE_EN				(1<<6)
#define HUSB311_REG_DISCHARGE_EN			(1<<5)
#define HUSB311_REG_BMCIO_LPRPRD			(1<<4)
#define HUSB311_REG_BMCIO_LPEN				(1<<3)
#define HUSB311_REG_BMCIO_BG_EN				(1<<2)
#define HUSB311_REG_VBUS_DET_EN				(1<<1)
#define HUSB311_REG_BMCIO_OSC_EN			(1<<0)

/*
 * HUSB311_REG_RT_STATUS				(0x97)
 */

#define HUSB311_REG_RA_DETACH				(1<<5)
#define HUSB311_REG_VBUS_80				(1<<1)

/*
 * HUSB311_REG_RT_INT				(0x98)
 */

#define HUSB311_REG_INT_RA_DETACH			(1<<5)
#define HUSB311_REG_INT_WATCHDOG			(1<<2)
#define HUSB311_REG_INT_VBUS_80				(1<<1)
#define HUSB311_REG_INT_WAKEUP				(1<<0)

/*
 * HUSB311_REG_RT_MASK				(0x99)
 */

#define HUSB311_REG_M_RA_DETACH				(1<<5)
#define HUSB311_REG_M_WATCHDOG				(1<<2)
#define HUSB311_REG_M_VBUS_80				(1<<1)
#define HUSB311_REG_M_WAKEUP				(1<<0)

/*
 * HUSB311_REG_IDLE_CTRL				(0x9B)
 */

#define HUSB311_REG_CK_300K_SEL				(1<<7)
#define HUSB311_REG_SHIPPING_OFF			(1<<5)
#define HUSB311_REG_ENEXTMSG				(1<<4)
#define HUSB311_REG_AUTOIDLE_EN				(1<<3)

/*
 * HUSB311_REG_EFUSE5					(0xF6)
 */

#define HUSB311_REG_M_VBUS_CAL				GENMASK(7, 5)
#define HUSB311_REG_S_VBUS_CAL				5
#define HUSB311_REG_MIN_VBUS_CAL			-4

/* timeout = (tout*2+1) * 6.4ms */

#ifdef CONFIG_USB_PD_REV30
#define HUSB311_REG_IDLE_SET(ck300, ship_dis, auto_idle, tout) \
	((ck300 << 7) | (ship_dis << 5) | (auto_idle << 3) \
	| (tout & 0x07) | HUSB311_REG_ENEXTMSG)
#else
#define HUSB311_REG_IDLE_SET(ck300, ship_dis, auto_idle, tout) \
	((ck300 << 7) | (ship_dis << 5) | (auto_idle << 3) | (tout & 0x07))
#endif

/*
 * HUSB311_REG_INTRST_CTRL			(0x9C)
 */

#define HUSB311_REG_INTRST_EN				(1<<7)

/* timeout = (tout+1) * 0.2sec */
#define HUSB311_REG_INTRST_SET(en, tout) \
	((en << 7) | (tout & 0x03))

/*
 * HUSB311_REG_WATCHDOG_CTRL		(0x9D)
 */

#define HUSB311_REG_WATCHDOG_EN				(1<<7)

/* timeout = (tout+1) * 0.4sec */
#define HUSB311_REG_WATCHDOG_CTRL_SET(en, tout)	\
	((en << 7) | (tout & 0x07))

/*
 * HUSB311_REG_I2CRST_CTRL		(0x9E)
 */

#define HUSB311_REG_I2CRST_EN				(1<<7)

/* timeout = (tout+1) * 12.5ms */
#define HUSB311_REG_I2CRST_SET(en, tout)	\
	((en << 7) | (tout & 0x0f))

#if ENABLE_HUSB311_DBG
#define HUSB311_INFO(format, args...) \
	pd_dbg_info("%s() line-%d: " format,\
	__func__, __LINE__, ##args)
#else
#define HUSB311_INFO(foramt, args...)
#endif

#endif /* #ifndef __LINUX_HUSB311_H */
